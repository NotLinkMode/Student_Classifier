import tensorflow as tf
import scipy
from keras.preprocessing.image import ImageDataGenerator

# %%
from keras.models import load_model, save_model
import numpy as np
import cv2

from skimage.transform import resize

from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Conv2D
from keras.layers import MaxPool2D
from keras.layers import Flatten

train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True)
training_set = train_datagen.flow_from_directory(
    'training/who_and_whom',
    target_size=(64, 64),
    batch_size=32,
    class_mode='categorical')

test_gen = ImageDataGenerator(rescale=1. / 255)
test_set = train_datagen.flow_from_directory(
    'testing/who_and_whom',
    target_size=(64, 64),
    batch_size=32,
    class_mode='categorical', shuffle=True)
#
# model = Sequential()
#
# model.add(Conv2D(32, (3, 3), input_shape=(64, 64, 3), activation='relu'))
# model.add(MaxPool2D(pool_size=(2, 2)))
#
# model.add(Conv2D(64, (3, 3), activation='relu'))
# model.add(MaxPool2D(pool_size=(2, 2)))
#
# model.add(Flatten())
#
# model.add(Dense(units=128, activation="relu"))
# model.add(Dense(units=3, activation="softmax"))  # Three units for three classes with softmax activation
#
# model.compile(loss="categorical_crossentropy", optimizer="adam", metrics=["accuracy"])
#
# model.summary()
#
# model.fit(x=training_set, validation_data=test_set, epochs=25)
#
# save_model(model, 'cnn_cd.h5')
loaded_model = load_model(r'cnn_cd.h5')


def detect(_frame):
    try:
        img = resize(_frame, (64, 64))
        img = np.array([img])
        if np.max(img) > 1:
            img = img / 255.0
        predictions = loaded_model.predict(img)

        class_labels = training_set.class_indices
        predicted_class = np.argmax(predictions)

        for label, index in class_labels.items():
            if index == predicted_class:
                predicted_label = label
                break
        print("Predicted Class Label: ", predicted_label)
        print("Predicted Class Probabilities: ", predictions)
    except Exception as e:
        print(e)


frame = cv2.imread(r"amma.jpg")
detect(frame)

# %%
